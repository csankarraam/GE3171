carSensors = [["BMW",200],["TESLA",24],["AUDI",75],["JAGUAR", 120]]
print('Our list is: ',carSensors)
length = len(carSensors)
print('Length of the list is: ',length)
carSensors.append(["BENZ", 90])
print('Now our list is: ',carSensors)
print("CAR SENSORS")
print("-----------")
for i in range(len(carSensors)):
    print(*carSensors[i])    
        
