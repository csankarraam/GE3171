d = eval(input("Enter diameter of steel bar (in meter) : "))
weight = d*d/162
print ("Weight of steel bar = ",round(weight,2),"kg/m")
