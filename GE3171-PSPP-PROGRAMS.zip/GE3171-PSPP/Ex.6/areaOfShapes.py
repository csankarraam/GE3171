def square(s):
      return (s*s)

def rectangle(l,b):
      return (l*b)

s = eval(input("Enter side of square: "))
l, b = map(int, input("Enter two values: ").split())
print ("Area of square =", square(s))
print ("Area of rectangle =", rectangle(l, b))

