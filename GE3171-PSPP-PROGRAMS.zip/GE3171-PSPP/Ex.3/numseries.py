num=int(input("Enter a number: "))
a=[]
for i in range(1,num+1):
    print(i,sep=" ",end=" ")
    if(i<num):
        print("+",sep=" ",end=" ")
    a.append(i)
print("=",sum(a))


