def gradePt(m):
    if m >= 91 and m <= 100 :
        gp = 'A'
    elif m >= 81 and m <= 90 :
        gp = 'B'
    elif m >= 71 and m <= 80 :
        gp = 'C'
    elif m >= 61 and m <= 70 :
        gp = 'D' 
    elif m >= 51 and m <= 60 :
        gp = 'E'
    else:
        gp = 'U'
    return gp
marks = { "kiwi": [99, 97, 90], "maizy":[95, 97, 96]}
f = open("F:\\grade.txt", "w")
f.write('---------------------------------------------------------- \n')
f.write('Name \t Maths \t Physics \t Chemistry\n')
f.write('---------------------------------------------------------- ')
for x in marks:
    f.write ("\n %s \t" % x)
    for i in marks[x]:
        gP = gradePt(i)
        f.write('%s \t' % gP)
f.close()
