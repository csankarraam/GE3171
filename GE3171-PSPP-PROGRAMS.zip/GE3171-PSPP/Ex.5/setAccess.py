materials={'Brick', 'Wood', 'Pipe', 'Cement', 'Sand'}
print('Our set is: ',materials)
length = len(materials)
print('Length of the set is: ',length)
newMaterial = {'steel bar'}
materials.update(newMaterial)
print('After addition: ', materials)
for item in materials:
    print(item)


