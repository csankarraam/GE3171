pen = 5
pencil = 3
eraser = 2
print("Retail Bill Calculator\n")
print("Enter the quantity of the ordered items:\n")
count_pen = int(input("Pen:"))
count_pencil =int(input("Pencil:"))
count_eraser = int(input("Eraser:"))
cost = count_pen * pen + count_pencil * pencil + count_eraser * eraser
print("Please pay Rs.%f"%cost,"INR") 
