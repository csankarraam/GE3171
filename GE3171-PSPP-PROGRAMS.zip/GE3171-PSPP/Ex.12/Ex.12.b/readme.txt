1. Copy all directories (data, image and music) into your PC

2. Check the hierarchy of files as follows 

C:/Python
|   carRace.py
|    
+---data
|       save.dat
|       
+---image
|       car1.png
|       car2.png
|       car3.png
|       car4.png
|       left.png
|       right.png
|       
\---music
        car.wav
        crash.wav
        laugh.wav 

2. Execute the program carRace.py


        
