mass = int(input("Enter the combined mass of motorcycle:"))
weight = mass * 9.81

print("Your bike weighs {} Newtons.".format(weight))
if(weight<10):
    print("Your bike weighs less than 10 Newtons and is too light.")
if(weight>1000):
    print("Your bike weighs more than 1000 Newtons and is too heavy.")
