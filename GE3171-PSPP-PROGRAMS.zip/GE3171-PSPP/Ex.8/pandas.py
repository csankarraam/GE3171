import pandas as pd
df = pd.DataFrame({'X':[78,23,45,54,65],'Y':[123,34,56,78,12]})
print(df)
