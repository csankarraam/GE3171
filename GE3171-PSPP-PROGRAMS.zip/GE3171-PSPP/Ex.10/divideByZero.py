x = int(input("enter numerator:"))
y = int(input("enter denominator:"))
try:
  z = x/y
except:
   	print("divide by zero error")
