airportCodes = {"TCR":"Tuticorin",
            "IXM":"Madurai",
            "TRZ":"Tiruchirappalli",
            "MAA":"Chennai",
            "CJB":"Coimbatore",
            "SXV":"Salem"
           }
print('Our Dictionary is: ', airportCodes)
length = len(airportCodes)
print('Length of the Dictionary is: ',length)
if "TRZ" in airportCodes:
      print(airportCodes["TRZ"])
else:
      print("Airport code not recognised")



