file_to_read = "C:\\File1.txt"
write_to_file = "C:\\File2.txt"
file = open (file_to_read, "r")
data = file.read()
file.close()
with open (write_to_file, "a") as file:
    file.write ( data )
print("Copied Data from File1 and write to File2")
