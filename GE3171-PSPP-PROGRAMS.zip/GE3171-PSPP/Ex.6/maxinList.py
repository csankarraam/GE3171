def maxinList(list):
      max = list[0]
      for a in list:
            if a>  max:
                  max = a
      return max

print("Largest is: ", maxinList([2, 99, 5, 23, 51]))

