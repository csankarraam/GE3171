s = int(input("Enter the value of s: "))
n = int(input("Enter the value of n: "))
sign = -1
fc = i =1
sum = 0
while i<=n:
    p = 1
    fc = 1
    for j in range(1,i+1):
        p = p*s
        fc = fc*j
    sign = -1*sign
    sum = sum + sign* p/fc
    i = i+2
print("sin("+str(s)+")=",sum)
