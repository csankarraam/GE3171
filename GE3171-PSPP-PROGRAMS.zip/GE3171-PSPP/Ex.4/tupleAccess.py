majorParts = ("Chassis", "Engine", "Body", "Wheels")
print('Our tuple is: ', majorParts)
length = len(majorParts)
print('Length of the tuple is: ',length)
indexOfEngine=majorParts.index('Engine')
print('Index of Engine is: ',indexOfEngine)
print("The main parts of automobile are: ") 
for item in majorParts:
    print(item)

