def calcBill(units):
    if(units<0):
     print("It is not a valid input")
     exit(0)
    else:
        if(units>=0 and units <=100):
            amt = 0
        elif(units>100 and units <=200):
            amt = (units-100)*1.5
        elif(units>200 and units <=500):
            amt = (units-200)*3+100*2
        else:
            amt = (units-500)*6.6+100*3.5+300*4.6
    return amt

units = float(input("Enter unit:"))

print("Your bill is ", calcBill(units), "INR")
