import matplotlib.pyplot as plt
import numpy as np
x = np.random.normal(150, 10, 200)
plt.hist(x)
plt.show()
