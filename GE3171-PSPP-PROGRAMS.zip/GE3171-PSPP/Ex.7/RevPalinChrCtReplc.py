def reverse(x):
  return x[::-1]

def palin(my_string):
      if(my_string==my_string[::-1]):
            return "The string is a palindrome"
      else:
            return "The string isn't a palindrome"
def countCh(my_str, c):
      count = 0  
      for i in my_str:
            if i == c:
                  count = count + 1  
      print ("Count of m in string madam is : " +  str(count))

def replaceStr(my_str,s,r):
      return my_str.replace(s,r)
      

myString = reverse("madam")
print("string reverse is: ", myString)
myString = palin("madam")
print(myString)
myString = countCh("madam", "m")
myString = replaceStr("madam","m", "k")
print("After replacement of m with k: ",myString)
